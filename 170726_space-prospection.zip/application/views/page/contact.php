<div id="body">
    <div class="header">
        <div class="contact">
            <h1>Contact</h1>
            <h2>DO NOT HESITATE TO CONTACT US</h2>
            <form>
                <input 
                    type="text" 
                    name="name" 
                    value="" 
                    placeholder="Name"
                >
                <input 
                    type="text" 
                    name="email" 
                    value="" 
                    placeholder="Email Address"
                >
                <input 
                    type="text" 
                    name="subject" 
                    value="" 
                    placeholder="Subject"
                >
                <textarea 
                    name="message" 
                    cols="50" 
                    rows="7"
                    placeholder="Message"
                ></textarea>
                <input type="submit" value="Send" id="submit">
            </form>
        </div>
    </div>
</div>