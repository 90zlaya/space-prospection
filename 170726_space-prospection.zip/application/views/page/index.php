<div id="body" class="home">
	<div class="header">
		<div>
			<img src="assets/images/satellite.png" alt="" class="satellite">
			<h1>SOYUZ TMA-M</h1>
			<h2>SPACECRAFT</h2>
			<div class="big"></div>
			<h3>FEATURED PROJECTS</h3>
			<ul>
				<li>
					<a><img src="assets/images/project-image1.jpg" alt=""></a>
				</li>
				<li>
					<a><img src="assets/images/project-image2.jpg" alt=""></a>
				</li>
				<li>
					<a><img src="assets/images/project-image3.jpg" alt=""></a>
				</li>
				<li>
					<a><img src="assets/images/project-image4.jpg" alt=""></a>
				</li>
			</ul>
		</div>
	</div>
	<div class="body">
		<div>
			<h1>OUR MISSION</h1>
			<p>Space exploration is the ongoing discovery and exploration of celestial structures in outer space by means of continuously evolving and growing space technology.</p>
		</div>
	</div>
</div>